﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TC5;


namespace TC5
{

    public class LibreriaInventario
    {
        public static void actualizarstock()
        {
            Console.Write("Ingresar Nombre del Producto: ");
            Program.nombre_producto = Console.ReadLine();
            Console.Write("Ingresar Stock: ");
            Program.stock = Console.ReadLine();
            bool cambio_strock = false;
            for (int x = 0; x <= 9; x++)
            {

                if (Program.registroproductos[x, 1] == Program.nombre_producto)
                {
                    ref string nuevostock = ref Program.registroproductos[x, 2];
                    nuevostock = Program.stock;
                    cambio_strock = true;

                }


            }

            if (cambio_strock == true) { Console.WriteLine("Se cambio Stock del producto: "); }
            else { Console.WriteLine("No se Realizo Cambio de Stock:Producto no encontrado "); }
            Console.Write("Precione cualquier tecla Volver a Menu: ");
            Console.ReadKey();
        }







    }
}