﻿using System;

class Program
{
    static double saldo = 1000;
    static int intentosFallidos = 0;
    static bool retiroBloqueado = false;

    static void Main()
    {
        int opcion;
        do
        {
            MostrarMenu();
            Console.Write("Seleccione una opción (1-4): ");
            if (!int.TryParse(Console.ReadLine(), out opcion))
            {
                MostrarError("Opción inválida. Intente nuevamente.");
                continue;
            }

            switch (opcion)
            {
                case 1:
                    MostrarSaldo();
                    break;
                case 2:
                    if (retiroBloqueado)
                    {
                        MostrarError("Retiros bloqueados por exceso de intentos fallidos.");
                    }
                    else
                    {
                        Console.Write("Ingrese monto a retirar: ");
                        if (double.TryParse(Console.ReadLine(), out double montoRetiro))
                        {
                            bool exito = ValidarYProcesarRetiro(montoRetiro);
                            if (!exito)
                            {
                                intentosFallidos++;
                                MostrarError($"Intento fallido #{intentosFallidos}");
                                if (intentosFallidos >= 3)
                                {
                                    retiroBloqueado = true;
                                    MostrarError("Se han bloqueado los retiros por exceder el número de intentos.");
                                }
                            }
                        }
                        else
                        {
                            MostrarError("Monto inválido.");
                        }
                    }
                    break;
                case 3:
                    Console.Write("Ingrese monto a depositar: ");
                    if (double.TryParse(Console.ReadLine(), out double montoDeposito))
                    {
                        bool exito = ValidarYProcesarDeposito(montoDeposito);
                        if (!exito)
                        {
                            MostrarError("Monto inválido para depósito. Debe ser mayor a 0.");
                        }
                    }
                    else
                    {
                        MostrarError("Monto inválido.");
                    }
                    break;
                case 4:
                    MostrarMensaje("Gracias por usar el cajero. ¡Hasta pronto!");
                    break;
                default:
                    MostrarError("Opción fuera del rango. Intente nuevamente.");
                    break;
            }

        } while (opcion != 4 && !retiroBloqueado);
    }