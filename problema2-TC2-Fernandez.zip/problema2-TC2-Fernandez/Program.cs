﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace promedionotas
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("--- Calculadora de Promedio ---");

            
            Console.Write("Ingrese la primera nota: ");
            double nota1 = double.Parse(Console.ReadLine()); 

            Console.Write("Ingrese la segunda nota: ");
            double nota2 = double.Parse(Console.ReadLine()); 

            Console.Write("Ingrese la tercera nota: ");
            double nota3 = double.Parse(Console.ReadLine()); 

           
            double promedio = (nota1 + nota2 + nota3) / 3; 

            
            Console.WriteLine($"El promedio del estudiante es: {promedio:F2}"); 

            
            if (promedio >= 13)
            {
                Console.WriteLine("Estado: Aprobado"); 
            }
            else
            {
                Console.WriteLine("Estado: Desaprobado"); 
            }
        }
    }
}
