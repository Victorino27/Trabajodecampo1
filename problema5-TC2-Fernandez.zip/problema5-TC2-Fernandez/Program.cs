﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace descuentodecompras
{
    internal class Program
    {
        static void Main(string[] args)
        {

            {
                double montoCompra, descuento = 0, totalPagar;

               
                Console.Write("Ingrese el monto de la compra (S/): ");
                montoCompra = Convert.ToDouble(Console.ReadLine());

               
                if (montoCompra > 200)
                {
                    descuento = montoCompra * 0.15;
                }

                
                totalPagar = montoCompra - descuento;

                
                Console.WriteLine($"\nSubtotal      : S/ {montoCompra:F2}");
                Console.WriteLine($"Descuento (15%): S/ {descuento:F2}");
                Console.WriteLine($"Total a pagar : S/ {totalPagar:F2}");
            }
        }

    }
}

