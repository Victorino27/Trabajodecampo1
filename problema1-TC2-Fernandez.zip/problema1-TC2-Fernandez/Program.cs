﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace conversiondetemperatura2
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Console.Write("Ingrese la temperatura en grados Celsius: ");
            double celsius = Convert.ToDouble(Console.ReadLine());

            double fahrenheit = (celsius * 9 / 5) + 32;
            double kelvin = celsius + 273.15;

            Console.WriteLine($"Temperatura en Celsius: {celsius}°C");
            Console.WriteLine($"Temperatura en Fahrenheit: {fahrenheit}°F");
            Console.WriteLine($"Temperatura en Kelvin: {kelvin}K");
        }
    }
}
